export default class OrdersAnalyzer {
  constructor() {
    this.weekdays = [
      "SUNDAY",
      "MONDAY",
      "TUESDAY",
      "WEDNESDAY",
      "THURSDAY",
      "FRIDAY",
      "SATURDAY",
    ];
  }

  totalQuantity(productId, orders) {
    // TODO: Implement
    // 1.create an output object that holds the result
    let output = {};
    // 2. loop over the weekdays and assign each day as key and its value is 0 in the output

    // 3.map through the orders
    orders.map((order) => {
      // 4. map through the orderLines
      order.orderLines.map((orderLine) => {
        if (orderLine.productId === productId) {
          const day = new Date(order.creationDate).getDay();
        }
      });
    });

    return output;
  }
}
